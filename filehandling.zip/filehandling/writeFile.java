package filehandling;

import java.io.FileWriter;
import java.io.IOException;

public class writeFile {

	public static void main(String[] args) {
		String data ="My name is Anirudh, I am from Tirupati, AP. ";
		
		try {
			FileWriter output = new FileWriter("anirudh.txt");
			output.write(data);
			System.out.println("Data is writted successfully");
			output.close();
		} catch (IOException e) {
			System.out.println("File write error....");
		}

	}

}


