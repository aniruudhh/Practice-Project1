package tryandcatch;

public class MyClass 
{
    public static void main(String args[]) 
    {
        int[] array = new int[7];
        try 
        {
            array[7] = 7;
        }
        catch (Exception e) 
        {
            System.out.println("Today is not my birthday!"); 
        }
        finally 
        {
            System.out.println("It is on July " + array.length);
        }
    }
}
