package inheritance;

public class Test  
{ 
    public static void main(String args[])  
    { 
        MountainBike mb = new MountainBike(4, 120, 20); 
        System.out.println(mb.toString());
    } 
}
